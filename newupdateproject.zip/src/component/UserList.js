import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useDispatch, useSelector } from 'react-redux';
import {  userInfoActions } from '../Redux/actions/userInfoActions';
import Paper from '@mui/material/Paper';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import { Button, Dialog, DialogActions, DialogContent, DialogTitle, TextField } from '@mui/material';

const UserList = () => {
    const dispatch = useDispatch()
    const { userData } = useSelector((state) => state?.userData)
    
    const [open, setOpen] = useState(false); 
    const [editMode, setEditMode] = useState(false);
    const [editingUserId, setEditingUserId] = useState(null);
    const [newUser, setNewUser] = useState({
        id: '',
        username: '',
        email: '',
        phone: '',
        website: '',
        company: { name: '' },
        address: { suite: '', street: '', city: '', zipcode: '' }
});

    const handleClickOpen = () => {
        setOpen(true);
        setEditMode(false);
    };
const getdata = localStorage?.getItem("userToAdd")
    const handleClose = () => {
        setOpen(false);
        setNewUser({
            id: '',
            username: '',
            email: '',
            phone: '',
            website: '',
            company: { name: '' },
            address: { suite: '', street: '', city: '', zipcode: '' }
        });
    };

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setNewUser((prevUser) => ({
            ...prevUser,
            [name]: value
        }));
    };

    const handleAddressChange = (e) => {
        const { name, value } = e.target;
        setNewUser((prevUser) => ({
            ...prevUser,
            address: {
                ...prevUser.address,
                [name]: value
            }
        }));
    };
    const handleSubmit = (e) => {
        e.preventDefault();
        
        const userToUpdate = {
            ...newUser,
            id: editingUserId 
        };
    
        if (editMode) {
            const updatedUsers = userData.map((user) => 
                user.id === editingUserId ? userToUpdate : user
            );
            localStorage.setItem("userToAdd", JSON.stringify(updatedUsers)); 
            dispatch(userInfoActions(updatedUsers)); 
        } else {
            const userToAdd = {
                ...newUser,
                id: userData.length + 1 
            };
            localStorage.setItem("userToAdd", JSON.stringify([...userData, userToAdd]));
            dispatch(userInfoActions([...userData, userToAdd]));
        }
    
        handleClose();
    };
    const handleEdit = (user) => {
        setNewUser(user);
        setEditingUserId(user.id);
        setEditMode(true);
        setOpen(true);
    };


    useEffect(() => {
        axios.get('https://jsonplaceholder.typicode.com/users')
            .then((response) => {
                dispatch(userInfoActions(response?.data))
            })
            .catch((error) => {
                console.error('Error:', error);
            });
    }, []);

    const handleDelete = (id) => {
        const updatedUsers = userData.filter((user) => user.id !== id);
                const reassignedUsers = updatedUsers.map((user, index) => ({
            ...user,
            id: index + 1 
        }));
    
        localStorage.setItem("userToAdd", JSON.stringify(reassignedUsers)); 
        dispatch(userInfoActions(reassignedUsers)); 
    };
    return (
        <>
            <Button variant="contained" color="primary" style={{marginTop:"20px"}} onClick={handleClickOpen}>
                Add User
            </Button>

            <Dialog open={open} onClose={handleClose}>
                <DialogTitle>{editMode ? "Edit User" : "Add New User"}</DialogTitle>
                <DialogContent>
                    <form onSubmit={handleSubmit}>
                        <TextField
                            label="Username"
                            name="username"
                            value={newUser.username}
                            onChange={handleInputChange}
                            fullWidth
                            margin="dense"
                        />
                        <TextField
                            label="Email"
                            name="email"
                            value={newUser.email}
                            onChange={handleInputChange}
                            fullWidth
                            margin="dense"
                        />
                        <TextField
                            label="Phone"
                            name="phone"
                            value={newUser.phone}
                            onChange={handleInputChange}
                            fullWidth
                            margin="dense"
                        />
                        <TextField
                            label="Website"
                            name="website"
                            value={newUser.website}
                            onChange={handleInputChange}
                            fullWidth
                            margin="dense"
                        />
                        <TextField
                            label="Company"
                            name="company"
                            value={newUser?.company?.name}
                            onChange={(e) =>
                                setNewUser((prevUser) => ({
                                    ...prevUser,
                                    company: { name: e.target.value }
                                }))
                            }
                            fullWidth
                            margin="dense"
                        />
                        <TextField
                            label="Suite"
                            name="suite"
                            value={newUser?.address?.suite}
                            onChange={handleAddressChange}
                            fullWidth
                            margin="dense"
                        />
                        <TextField
                            label="Street"
                            name="street"
                            value={newUser?.address?.street}
                            onChange={handleAddressChange}
                            fullWidth
                            margin="dense"
                        />
                        <TextField
                            label="City"
                            name="city"
                            value={newUser?.address?.city}
                            onChange={handleAddressChange}
                            fullWidth
                            margin="dense"
                        />
                        <TextField
                            label="Zipcode"
                            name="zipcode"
                            value={newUser?.address?.zipcode}
                            onChange={handleAddressChange}
                            fullWidth
                            margin="dense"
                        />
                    </form>
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleClose} color="secondary">
                        Cancel
                    </Button>
                    <Button onClick={handleSubmit} variant="contained" color="primary">
                        {editMode ? "Update User" : "Add User"}
                    </Button>
                </DialogActions>
            </Dialog>

            <TableContainer component={Paper} style={{ boxShadow: 'none' }}>
                <Table sx={{ minWidth: 750, boxShadow: 'none' }} aria-label="simple table">
                    <TableHead>
                        <TableRow>
                            <TableCell style={{ fontSize:16, fontWeight:800 } }>Id</TableCell>
                            <TableCell align="center" style={{ fontSize:16, fontWeight:800 } }>Name</TableCell>
                            <TableCell align="center" style={{ fontSize:16, fontWeight:800 } }>Email</TableCell>

                            <TableCell align="center" style={{ fontSize:16, fontWeight:800 } }>Phone</TableCell>
                            <TableCell align="center" style={{ fontSize:16, fontWeight:800 } }>Website</TableCell>
                            <TableCell align="center" style={{ fontSize:16, fontWeight:800 } }>Company</TableCell>
                            <TableCell align="center" style={{ fontSize:16, fontWeight:800 } }>Address</TableCell>
                            <TableCell align="center" style={{ fontSize:16, fontWeight:800 } }>Actions</TableCell> {/* New column for actions */}

                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {userData?.map((item, index) => (
                            <TableRow key={index}>
                                <TableCell component="th" scope="row">{item?.id}</TableCell>
                                <TableCell align="right">{item?.username}</TableCell>
                                <TableCell align="right">{item?.email}</TableCell>

                                <TableCell align="right">{item?.phone}</TableCell>
                                <TableCell align="right">{item?.website}</TableCell>
                                <TableCell align="right">{item?.company?.name}</TableCell>
                                <TableCell align="right">
                                    {item?.address?.suite} {item?.address?.street} {item?.address?.city} {item?.address?.zipcode}
                                </TableCell>
                                <TableCell align="right">
                                    <Button onClick={() => handleEdit(item)} color="primary" size="small">
                                        Edit
                                    </Button>
                                    <Button onClick={() => handleDelete(item.id)} color="secondary" size="small">
                                        Delete
                                    </Button>
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </TableContainer>

        </>
    )
}

export default UserList 