import { createStore, combineReducers, applyMiddleware } from 'redux';
import {thunk} from 'redux-thunk';
import { composeWithDevTools } from 'redux-devtools-extension';
import storage from 'redux-persist/lib/storage'
import { persistStore, persistReducer } from 'redux-persist'
import { userInfoReducers } from "./reducers/userInfoReducers";
import createIdbStorage from '@piotr-cz/redux-persist-idb-storage'
import { createStateSyncMiddleware, initMessageListener } from 'redux-state-sync';

const appReducer = combineReducers({
    userData: userInfoReducers
})

const persistConfig = {
    key: "root",
    version: 1,
    storage,
    whiteList: [
        "userData"
    ]
}
const persistedReducer = persistReducer (persistConfig,appReducer) 
const syncMiddleware = createStateSyncMiddleware({
    whitelist: [
     "userData"
    ],
    broadcastChannelOption: {
      type: 'localstorage', 
      persistence: 'permanent', 
    },
  });
  
 
  const store = createStore(persistedReducer, composeWithDevTools(applyMiddleware(thunk, syncMiddleware)));
  initMessageListener(store);

  const persistor = persistStore(store);
  
  export { persistor, store };