import { ADD_USER, FETCH_USER_INFO_FAILED, FETCH_USER_INFO_REQUEST, FETCH_USER_INFO_SUCCESS } from "../constants/userInfoConstants";


export const userInfoReducers = (state = { userData: [], }, { type, payload }) => {
    switch (type) {
        case FETCH_USER_INFO_REQUEST:
            return { ...state }
        case FETCH_USER_INFO_SUCCESS:
            return { ...state, userData: payload }
        case FETCH_USER_INFO_FAILED:
            return { ...state, error: payload }
          
        default: return state
    }

}