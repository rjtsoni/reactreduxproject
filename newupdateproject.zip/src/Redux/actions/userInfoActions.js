import { FETCH_USER_INFO_FAILED, FETCH_USER_INFO_REQUEST, FETCH_USER_INFO_SUCCESS,ADD_USER } from "../constants/userInfoConstants"

export const userInfoActions = (data) => async (dispatch)=> {
    try {
        dispatch({type: FETCH_USER_INFO_REQUEST})
        dispatch({type: FETCH_USER_INFO_SUCCESS ,payload :data})
    } catch (error) {
        dispatch({type: FETCH_USER_INFO_FAILED})
    }
}
